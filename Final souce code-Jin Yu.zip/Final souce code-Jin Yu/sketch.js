let MAX_PARTICLES = 1000;
let MAX_TRIANGLES = 2000;
let MAX_PARTICLE_SPEED = 1.0;
let SIZE = 4;
let LIFESPAN_DECREMENT = 1.0;
let MAX_TRI_DISTANCE = 30;
let MIN_TRI_DISTANCE = 3;
let MAX_PARTICLE_NEIGHBOURS = 10;
let MAX_WANDERER_SPEED = 50;
let SPAWN_DELAY = 80;
let PARTICLE_LIFESPAN = 255;

// Two systems reset for simultaneous setting of both hands
let system;
let system1;
let triangles;
let triangles1;
let spawner1;
let spawner;
let colour;
let colour1;

let per=0;

let isFist = false;
let isFist1 = false;

let   handp


let   boom=false
let   boom2=false
let   uy=0

let   sp1=true
let   sp2=true
let   sp3=true
let   sp4=true
let   sp5=true
let handpose;
let video;
let predictions = [];

let img1, img2, img3;
let fistCount = 0;


let dwq=2;
let state1 =-1;
let palmPos = [0, 0];
let processColor;
let ji=0
let  p1;

let tempChosen = -1;
let  uname=""

// Array of celebrity names that is used to display different user interface sections or categories
let   toptitle=["Cristiano Ronaldodos Santos Aveiro","Emma Charlotte Duerre Watson","Elon Reeve Musk"]
let img4

// Stores congratulatory messages displayed when certain trust levels and interest group levels are reached
let upgradeText=[
"Congratulations on reaching 5 levels of trust and 5 levels of your interest group!",
"Congratulations on reaching 10 levels of trust and 10 levels of your interest group!",
"Congratulations on reaching 15 levels of trust and 15 levels of your interest group!",
"Congratulations on reaching 20 levels of trust and 20 levels of your interest group!",
"Congratulations on reaching 25 levels of trust and 30 levels of your interest group!"]

// Contains prompts and congratulatory messages to guide the user
let tipText=[
". Please choose your interest group!",
". Please interact with your social network handshake!",
". Congratulations on reaching 5 levels of trust and 5 levels of your interest group!",
". Congratulations on reaching 10 levels of trust and 10 levels of your interest group!",
". Congratulations on reaching 15 levels of trust and 15 levels of your interest group!",
". Congratulations on reaching 20 levels of trust and 20 levels of your interest group!",
".Please choose your preferred interest group",
".Your trust level is insufficient, I have helped you to select the social group with matching level."]


// Create an empty array of soundlist to store my sound files.
let   soundlist=[]
//Initialise an empty array of thumbHistory, which can potentially be used in later code to store historical coordinate data related to the thumb
let thumbHistory = [];

let woshou=false
function preload() {
  // Preloaded images
  img1 = loadImage("images/interest(1).png");
  img2 = loadImage("images/1.png");
  img3 = loadImage("images/2.png");
  img4 = loadImage("images/4.png");
  p1 = loadImage("images/3.png");

  for(let i=0;i<14;i++){
    // Loop 14 times to load sound files into soundlist array
    soundlist[i]=loadSound("./sounds/"+(i+1)+".mp3")
  }
  processColor=[30,80,226,255];
  console.log(processColor);
}
function setup() {
   //createCanvas(windowWidth, windowHeight);
 
  
  createCanvas(3456,1944);

  // img2.resize(3456,1944)

  const options = {
    flipHorizontal: true, // boolean value for if the video should be flipped, defaults to false
    maxContinuousChecks: Infinity, // How many frames to go without running the bounding box detector. Defaults to infinity, but try a lower value if the detector is consistently producing bad predictions.
    detectionConfidence: 0.98, // Threshold for discarding a prediction. Defaults to 0.8.
    scoreThreshold: 0.75, // A threshold for removing multiple (likely duplicate) detections based on a "non-maximum suppression" algorithm. Defaults to 0.75
    iouThreshold: 0.3, // A float representing the threshold for deciding whether boxes overlap too much in non-maximum suppression. Must be between [0, 1]. Defaults to 0.3.
  };

  video = createCapture(VIDEO);
  video.size(640, 480);
  handpose = ml5.handpose(video, options, modelReady);

  // This sets up an event that fills the global variable "predictions"
  // with an array every time new hand poses are detected
  handpose.on("predict", (results) => {
    predictions = results;
    //console.log(results);
  });

  // Hide the video element, and just show the canvas
  // Setting up the initialisation system for both hands and other variables
  video.hide();
  noStroke();
  smooth();
  system = new ParticleSystem(0);
  system1 = new ParticleSystem(1);
  triangles = new TriangleSystem();
  triangles1 = new TriangleSystem();
  spawner = new Wanderer();
  spawner1 = new Wanderer();
  colour = new ColourGenerator();
  colour1 = new ColourGenerator();
  wrapText(textRoll , maxWidth);
}

function modelReady() {
  console.log("Model ready!");
}
// Defines the text rendering parameters. maxWidth defines the maximum width of the text, yPos is used to track the vertical position of the text drawing, and lineHeight defines the line height of the text.
let maxWidth=550;
let yPos=0;
let lineHeight = 45; 
function draw() {
  background(0);

  // By switch to set the case, the case presents the "web page" of my picture, and the state is used to control when to call it and switch the page.
  switch (state1) {
    case -1:
      image(p1, 0, 0, width, height);

      push()
      textAlign(CENTER)
      fill(255)
      textSize(40)
      text(uname,width/2-25,height*2/3+190)
      fill(100)
      
     if(uname.length==0) text("Please enter 3 digital number as username",width/2-25,height*2/3+190)

      pop ()
   
      break;
    case 0:
      image(img1, 0, 0, width, height);


      fill(255, 0, 0);
      ellipse(mouseX, mouseY, 20, 20);
      // if (predictions.length > 0) {
      //   // We can call both functions to draw all keypoints and the skeletons
      //   drawKeypoints();
      //   checkChosen();
      // }
      break;
    case 1: {
      image(img2, 0, 0, width, height);
      // background(0)
     
      push()
      fill(255)
      textSize(50)
      text(toptitle[tempChosen]+"\nStar Interset Group",50,100)
      textSize(36)
      text("the number of people — ",50,260)

      fill(233,9,155)
      text(system.particles.length,500,262)
      // text(system.particles.length,235,120)
      fill(255)
     
      if(!soundlist[12].isPlaying())soundlist[12].play()
      
      textSize(50)
      text(0,0,height-7)
      text(10,width/4,height-7)
      text(20,width*2/4,height-7)
      text(30,width*3/4,height-7)
      text(40,width-55,height-7)
      text("My trust level",30,height-95)

      push()
      textAlign(CENTER,CENTER)
      fill(219, 219, 219)
      ellipse(80,370,90,90)
      fill(233,9,155)
      textSize(42)
      text(uname,80,373)
   pop()
      pop()
      if (predictions.length > 0) {
        // We can call both functions to draw all keypoints and the skeletons
        drawProcess();
        drawKeypoints();
        triangles.clear();
        
        spawner.update();
        //system.addParticle(createVector(spawner.loc.x, spawner.loc.y));
        system.update(predictions[0]);
        triangles.display();
      }
      fill(0,255,0);
      // Show text after line feeds
      textSize(50)
      text("System alert",width*2/3-170,height*2/3+100)
      textSize(24)
      
      // shows the contents of the tipText array and determines the position of the text based on the number of iterations of the loop
      for (let i = 0; i < dwq; i++) {
        text((i+1)+tipText[i],width*2/3-170,height*2/3+100 + i * lineHeight+yPos+50);
          
      }

      // Here the fistCount is checked to see if it is between 5 and 10 (including 5, but not including 10).
      if(fistCount>=5&&fistCount<10){dwq=3
        if(sp1){

          sp1=false
          // Plays the audio file with index 2 from the soundlist array.
          soundlist[2].play()
        }
      }

      if(fistCount>=10&&fistCount<15){dwq=4

        if(sp2){

          sp2=false
          soundlist[3].play()
        }

      }
      if(fistCount>=15&&fistCount<20){dwq=5

        if(sp3){

          sp3=false
          soundlist[4].play()
        }

      }
      if(fistCount>=20&&fistCount<25){
        dwq=6
        if(sp4){

          sp4=false
          soundlist[5].play()
        }

        if(!sp4&&!soundlist[5].isPlaying()){

          state1=2
          soundlist[10].play()

          system1.particles=system.particles
          triangles1.triangles=triangles.triangles
        }

      }
      break;
    }
    case 2:
      image(img3, 0, 0, width, height);
      // background(0)
      
      push()
    
      // text("Lv."+fistCount,width/2+200,100)
      fill(255)
      textSize(50)
     
      text(toptitle[tempChosen]+"\nStar Interset Group",50,100)
      textSize(36)
      text("the number of people — ",50,260)

      fill(233,9,155)
      text(system.particles.length,500,262)
      

      image(img4, -9, 0, width, height);
      fill(0,255,0)
      console.log(handp,'fff')
     ellipse(width/2+350+map(handp,width/2,width,-100,100),height/2,30,30)
    //  console.log("🚀 ~ file: sketch.js:277 ~ draw ~ handp:", handp)

    //  1080 1375
      fill(255)
      textSize(50)
      if(handp<width/2+100+150&&isFist)fill(233,9,155)
      else fill(255)
      text("Lv.40",300,340)
      

      if(handp>width/2+100+450&&isFist)fill(233,9,155)
      else fill(255)
      text("Lv.20",width/2+400,220)
      fill(255)
      text("Please select the group you tend to shake hands with",250,165)
      push()
      translate (340,height-260)

      if(handp<width/2+100+150&&isFist){fill(233,9,155),dwq=8
        if(!soundlist[11].isPlaying()&&!boom) soundlist[11].play()
        boom=true
       }

       if(handp<width/2+100+150&&boom)fill(233,9,155)
      ellipse(0,0,90,90)
      // if(handp<width/2+100){fill(233,9,155),dwq=8
      //  if(!soundlist[11].isPlaying()&&!boom) soundlist[11].play()
      //  boom=true
      // }


      if(boom&&!boom2){
        per+=1;
        
        uy+=1

        // Controls the speed of switching between A and B hands
        if(per%50==0){
         handp= handp==3000?50:3000
         
         if(handp==3000)soundlist[10].play()
         if(handp==50)soundlist[11].play()
        }

       
      }
      
     
      if(uy>5*60){
        dwq=88 //Controls the number of loops and determines how many lines of text are displayed
        boom2=true
        if(!soundlist[13].isPlaying())soundlist[13].play()

        

       }

       if(boom2){
        
        ji+=1
       if(ji>5*60)location.reload()

       }
       
      textAlign(CENTER,CENTER)
      textSize(50)
      fill(100)
      text("A",0,2)

     


      pop()


      push()
      translate (width/2+450,height/2+195)
      if(handp>width/2+100+450&&isFist&&!boom){fill(233,9,155),dwq=7,soundlist[13].stop()
        if(!soundlist[10].isPlaying()){soundlist[10].play()}
      
      }

      // Setting changes to the grey circular background of the A and B hand options
      else fill(219, 219, 219)
      if(handp>width/2+100+450&&boom)fill(233,9,155)
      ellipse(0,0,90,90)
      fill(233,9,155)
      textAlign(CENTER,CENTER)
      textSize(50)
      fill(100)
      text("B",2,2)


      pop()
     
      
      textSize(50)
      text(0,0,height-7)
      text(10,width/4,height-7)
      text(20,width*2/4,height-7)
      text(30,width*3/4,height-7)
      text(40,width-55,height-7)
      text("My trust level",30,height-95)
      fill(219, 219, 219)
      // ellipse(72,150,50,50)
      fill(233,9,155)
      // text(uname,50,160)

      pop()
      if (predictions.length > 0) {
        // We can call both functions to draw all keypoints and the skeletons

        push()

        translate(200,0)
        drawProcess();
        drawKeypoints();
        triangles.clear();

        spawner.update();

        // if(system.particles.length>360)system.particles=system.particles.slice(0,system.particles.length/3)

        system.update(predictions[0]);


        // if(triangles.triangles.length>360)triangles.triangles=triangles.triangles.slice(0,triangles.triangles.length/3)
        triangles.display();

        pop()

        // A range of drawing operations involving transformations of the coordinate system, calling custom functions, and clearing and updating graphical objects.
        push()
        translate(-width/2+200,0)
        drawKeypoints2();
        triangles1.clear();

        spawner1.update();
       
        system1.update1(predictions[0]);
        triangles1.display2();

        pop()
      }
      fill(0,255,0);
     
      

      if(dwq>=0&&dwq!=88){
        textSize(50)
      text("System alert",width*2/3-170,height*2/3+100)
      textSize(24)
      for (let i = 0; i < dwq; i++) {
        text((i+1)+tipText[i], width*2/3-170,height*2/3+100 + i * lineHeight+yPos+50);
          
      }
    }
      if(dwq==88){
        textSize(50)
        text("System alert",width*2/3-170,height*2/3+100)
        textSize(24)
        let dW=0;
    
      for (let i = yPos; i < yPos+8; i++) {
        text((i+1)+tipText[i],width*2/3-170,height*2/3+100 + dW * lineHeight+50);
          dW=dW+1;
      }
      tipText.push(tipText[yPos%8])
      yPos=yPos+1;
      // if(yPos+8>=wrappedText.length){
      //   yPos=0;
      // }
      }
      break;
  }
  // image(video, 0, 0, width * 0.2, height * 0.2);
}
let ftSize1=12;
function wrapText(text, maxWidth) {
      textSize(ftSize1);
  let words = text.split(' ');
  let currentLine = '';
  
  for (let i = 0; i < words.length; i++) {


    wrappedText.push( words[i])
    // let testLine = currentLine + words[i] + ' ';
    // let testWidth = textWidth(testLine);
    
    // if (testWidth+100 > maxWidth && i > 0) {
    //   wrappedText.push(currentLine);
    //   currentLine = words[i] + ' ';
    // } else {
    //   currentLine = testLine;
    // }
  }
  
  // wrappedText.push(currentLine);
}
function drawProcess(){

  push()
  let deltaXX=map(fistCount,0,40,0,width);

  if(state1==2)deltaXX=width/2-200
  img2.loadPixels();
  processColor=img2.get(map(0+deltaXX,0,width,0,1920),1060);
  fill(processColor);
  console.log(processColor);
  // translate

  // fill(255,0,0)
  // deltaXX=width/2-200
  triangle(-20+deltaXX,height-90,0+deltaXX,height-60,20+deltaXX,height-90);

  pop()
}

//checkChosen Checks a point as the position of the hand to approach a preset point.
function checkChosen() {
  let checkPt = [
    [width / 2 - 0.14 * width, height / 2],
    [width / 2, height / 2],
    [width / 2 + 0.14 * width, height / 2],
  ];
  //console.log(palmPos[0], palmPos[1], isFist);
 
  // If a close checkpoint is found (tempChosen >= 0) and isFist is true indicating that a fist action was detected, the selected point is recorded and the state of the program is changed (state1 = 1).
  for (let i = 0; i < 3; i++) {
    if (
      dist(palmPos[0], palmPos[1], checkPt[i][0], checkPt[i][1]) <
      0.06 * width
    ) {
      tempChosen = i;
      break;
    }
    fill(255, 0, 0);
    ellipse(checkPt[i][0], checkPt[i][1], 20, 20);
  }
  if (tempChosen >= 0 && isFist) {
    console.log(tempChosen);
    state1 = 1;
  }
}


function mouseClicked(){
  console.log(mouseX,mouseY)

  if(state1==0){

    let checkPt = [
      [width / 2 - 0.14 * width, height / 2],
      [width / 2, height / 2],
      [width / 2 + 0.14 * width, height / 2],
    ];
    //console.log(palmPos[0], palmPos[1], isFist);
    // let tempChosen = -1;
    for (let i = 0; i < 3; i++) {
      if (
        dist(mouseX, mouseY, checkPt[i][0], checkPt[i][1]) <
        0.06 * width
      ) {
        console.log(i)
        tempChosen = i;
        state1 = 1;
        soundlist[1].play()
        break;
      }
      
    }
  



  }


}
function keyPressed(){

  if(uname.length<3){

    uname+=key
  }

  if(keyCode==ENTER&& state1==-1&&uname.length==3){

    state1=0
    soundlist[0].play()
  }


}
// Previously cancelled code for determining hand movements by mean square error
function drawKeypoints() {
  let totalX = 0; // Sum of X-coordinates of all key points
  let totalY = 0; // Sum of Y coordinates of all key points
  let totalError = 0; // Used to store the total mean square error

  //This comes from the predictions identified by p5.js's handpose model, each prediction in the predictions array, and drawing keypoints and shapes based on those results
  for (let i = 0; i < predictions.length; i += 1) {
    const prediction = predictions[i];
    let landmarks = predictions[0].landmarks;
    if(!boom)handp=transX(prediction.landmarks[0][0])

    console.log(handp)
    push()
    beginShape();
    for (let j = 1; j < prediction.landmarks.length; j += 1) {
      const keypoint = prediction.landmarks[j];
      const keypoint1 = prediction.landmarks[j-1];

    
// Create borderless triangles with transparency
      fill(0, 255, 0);
      noStroke();
     if(state1!=23||(transX(keypoint[0])>950-200&&transY(keypoint[1])>43&&transY(keypoint[1])<593)) ellipse(transX(keypoint[0]), transY(keypoint[1]), 4, 4);
      stroke(255,100)
      if(state1!=23||transX(keypoint[0])>950-200&&transY(keypoint[1])>43&&transY(keypoint[1])<593)line(transX(keypoint[0]), transY(keypoint[1]),transX(keypoint1[0]), transY(keypoint1[1]))
    }
    endShape();
    pop()

    // This loop iterates over the keypoints in the prediction.landmarks array, indexed from 8 to 20, at intervals of 4, which are the joint positions of the fingers).
    // If the horizontal coordinates of these keypoints are less than the horizontal coordinates of the thumb (index 4), then the variable woshou is set to indicate the state of the "handshake", which is a simple way of checking that the palm of the hand is closed into a fist.
    for(let i=8;i<24;i+=4){
      if(prediction.landmarks[i][0]<prediction.landmarks[4][0]){
        
        woshou=false
      }
      else{
        woshou=true
      }
      
    }
    //Get Key Points for Thumb and Little Finger
    let thumb = landmarks[4];
    let pinky = landmarks[20];
    
    //Another key point in acquiring the pinky
    let pinky2 = landmarks[19];

    //Repeat the key point of assigning thumbs
    let x=landmarks[4];

    let thumbX = thumb[1];

    // landmarks[9][0]+width/2-200
   
    
    thumbHistory.push(thumbX);
    
    if (thumbHistory.length > 10) {
      thumbHistory.shift();
    }
    // [20,20,20,20,100,20,20]
    if ( thumb[1]<pinky[1]) {
      // Determining Whether or Not to Cross Hands
       if(woshou){
      console.log("握手了")//Shake hands
      let thumbDiff = max(thumbHistory) - min(thumbHistory);
    
      if (thumbDiff > 50&& isFist == false) {
        console.log("大拇指晃动了");//Thumbs up
        isFist = true;
        // alert(6688)
        if (state1 >= 1) {
          for (let i = 0; i < MAX_PARTICLES/50; i++) {
            system.addParticle(prediction);
          }
  
          if(state1!=2)fistCount += 1;
        }
        if(fistCount==25){
          system.crazy(100);
        }else if(fistCount==30){
          system.crazy(300);
        }else if(fistCount==40){
          system.crazy(600);
        }
      } else {
        // isFist = false;
        console.log("大拇指稳定");// Thumbs up for stability
      }
    }
    else{
      isFist = false;
    }
    } else {
      console.log("手是竖向的");//The hands are vertical.
    }
  
  }
}
function drawKeypoints2() {
  

  for (let i = 0; i < predictions.length; i += 1) {
    const prediction = predictions[i];
    for (let j = 1; j < prediction.landmarks.length; j += 1) {
      const keypoint = prediction.landmarks[j];
      const keypoint1 = prediction.landmarks[j-1];
      fill(0, 255, 0);
      noStroke();
      if(transX(keypoint[0])>107+width/2-200&&transX(keypoint[0])<755+width/2-200&&transY(keypoint[1])>94&&transY(keypoint[1])<834)ellipse(transX(keypoint[0]), transY(keypoint[1]), 4, 4);
      stroke(0,20)
      if(state1!=23||transX(keypoint[0])>107+width/2-200&&transX(keypoint[0])<755+width/2-200&&transY(keypoint[1])>94&&transY(keypoint[1])<834)line(transX(keypoint[0]), transY(keypoint[1]),transX(keypoint1[0]), transY(keypoint1[1]))
     
    }
    

  }
}
// Adapts to canvas with different resolutions
function transX(xx) {
  return map(xx, 0, 640, 0, width);
}
function transY(yy) {
  return map(yy, 0, 480, 0, height);
}
function amplify(n) {
  return constrain(2 * n, 0, 255);
}

// ColourGenerator is mainly used to generate colours, but the speed of the colours is useless here, derived from an open framework reference.
class ColourGenerator {
  constructor() {
    this.MIN_SPEED = 0.2;
    this.MAX_SPEED = 0.7;
    this.R = processColor[0];
    this.G = processColor[1];
    this.B = processColor[2];
    this.Rspeed =
      (random(1) > 0.5 ? 1 : -1) * random(this.MIN_SPEED, this.MAX_SPEED);
    this.Gspeed =
      (random(1) > 0.5 ? 1 : -1) * random(this.MIN_SPEED, this.MAX_SPEED);
    this.Bspeed =
      (random(1) > 0.5 ? 1 : -1) * random(this.MIN_SPEED, this.MAX_SPEED);
  }

  update() {
    this.Rspeed =
      (this.R += this.Rspeed) > 255 || this.R < 0 ? -this.Rspeed : this.Rspeed;
    this.Gspeed =
      (this.G += this.Gspeed) > 255 || this.G < 0 ? -this.Gspeed : this.Gspeed;
    this.Bspeed =
      (this.B += this.Bspeed) > 255 || this.B < 0 ? -this.Bspeed : this.Bspeed;
  }
}

// Systems for managing particles
class Particle {
  constructor(pr) {
    this.velocity = createVector(
      random(-MAX_PARTICLE_SPEED, MAX_PARTICLE_SPEED),
      random(-MAX_PARTICLE_SPEED, MAX_PARTICLE_SPEED)
    );
    this.fixedPt = new GetPoints(pr);
    this.pos = this.fixedPt.offsetPoint;
    this.lifespan = PARTICLE_LIFESPAN;
    this.neighbours = [];
    this.limitR = random(20, 40);
    this.angle = random(0, TWO_PI);
    this.emoj=""
    if(tempChosen==0)this.emoj=random(1)>0.5?"⚽️":"🎉"
    if(tempChosen==2)this.emoj=random(1)>0.5?"🦸‍♂":"💰"
    if(tempChosen==1)this.emoj=random(1)>0.5?"🦸":"❤"
  }

  move(pr) {
    // this.pos.add(this.velocity);
    // if (this.pos.x > width) this.pos.x -= width;
    // if (this.pos.x < 0) this.pos.x += width;
    // if (this.pos.y > height) this.pos.y -= height;
    // if (this.pos.y < 0) this.pos.y += height;
    // this.lifespan -= LIFESPAN_DECREMENT;
    //this.fixedPt.update(pr);
    this.angle = this.angle + 0.01;
    if (this.angle > TWO_PI) {
      this.angle = this.angle - TWO_PI;
    }
    this.pos = this.fixedPt.update(pr);
    this.pos.x = this.pos.x + this.limitR * cos(this.angle) * cos(this.angle);
    this.pos.y = this.pos.y + this.limitR * sin(this.angle) * cos(this.angle);
  }

  accel(n) {
    
    this.limitR = random(n-20,n);
  }

  display() {
    noFill();
    fill(colour.R, colour.G, colour.B, this.lifespan);
    if(state1!=23||(this.pos.x>157+width/2-200&&this.pos.x<755+width/2-200&&this.pos.y>93&&this.pos.y<593))  {ellipse(this.pos.x, this.pos.y, SIZE, SIZE);

    textSize(36)

    fill(255,122+125*sin(this.angle*6))

    // 45 Adjust emoji distance
    text(this.emoj,this.pos.x, this.pos.y+45*sin(this.angle*6))}
  }

  isDead() {
    return this.lifespan < 0;
  }
}

class ParticleSystem {
  constructor(z) {
    this.z=z
    this.particles = [];
  }

  addParticle(pr) {
    if (this.particles.length < MAX_PARTICLES) {
      let part = new Particle(pr);
      this.particles.push(part);
    }
  }

  //The distance between particles is determined by the neighbourhood technique, so that particles that are close together make a triangle.
  discoverNeighbours() {
    for (let x = 0; x < this.particles.length; x++) {
      let p1 = this.particles[x];
      p1.neighbours = [];
      p1.neighbours.push(p1);
      for (let y = x + 1; y < this.particles.length; y++) {
        let p2 = this.particles[y];
        let distance = dist(p1.pos.x, p1.pos.y, p2.pos.x, p2.pos.y);
        if (distance > MIN_TRI_DISTANCE-60 && distance < MAX_TRI_DISTANCE+60) {
          p1.neighbours.push(p2);
        }
      }
      if (
        p1.neighbours.length > 1 &&
        p1.neighbours.length < MAX_PARTICLE_NEIGHBOURS
      ) {
        triangles.addTriangles(p1.neighbours);
      }
    }
  }
  discoverNeighbours1() {
    for (let x = 0; x < this.particles.length; x++) {
      let p1 = this.particles[x];
      p1.neighbours = [];
      p1.neighbours.push(p1);
      for (let y = x + 1; y < this.particles.length; y++) {
        let p2 = this.particles[y];
        let distance = dist(p1.pos.x, p1.pos.y, p2.pos.x, p2.pos.y);
        if (distance > MIN_TRI_DISTANCE-70 && distance < MAX_TRI_DISTANCE+70) {
          p1.neighbours.push(p2);
        }
      }
      if (
        p1.neighbours.length > 1 &&
        p1.neighbours.length < MAX_PARTICLE_NEIGHBOURS
      ) {
        triangles1.addTriangles(p1.neighbours);
      }
    }
  }

  // Enriching the effects of exercise
  crazy(n){
    
    for (let i = this.particles.length - 1; i >= 0; i--) {
      let p = this.particles[i];
      p.accel(n);
    }
  }
  update(pr) {
    for (let i = this.particles.length - 1; i >= 0; i--) {

    
    
        let p = this.particles[i];
      p.move(pr);
         if(i%4==0){
      p.display();

      }
      
    }
    colour.update();
    if(this.z==0)this.discoverNeighbours();
    if(this.z==1)this.discoverNeighbours1();
  }
  update1(pr) {
    for (let i = this.particles.length - 1; i >= 0; i--) {

      // if(state1==2){
       
        let p = this.particles[i];
        p.move(pr);
        p.display();
      // }
      //  if(state1!=2&&i%3==0){
      //   let p = this.particles[i];
      // p.move(pr);
      // p.display();

      // }
      
    }
    colour.update();
    if(this.z==0)this.discoverNeighbours();
    if(this.z==1)this.discoverNeighbours1();
  }
}
// Set the three vertices of the triangle to three particles
class Triangle {
  constructor(p1, p2, p3) {
    this.A = p1;
    this.B = p2;
    this.C = p3;
  }

//Drawing vertices 
  display() {
    if(state1!=23||(this.A.x>157+width/2-200&&this.A.x<755+width/2-200&&this.A.y>93&&this.A.y<593)) vertex(this.A.x, this.A.y);
    if(state1!=23||(this.B.x>157+width/2-200&&this.B.x<755+width/2-200&&this.B.y>93&&this.B.y<593))vertex(this.B.x, this.B.y);
    if(state1!=23||(this.C.x>157+width/2-200&&this.C.x<755+width/2-200&&this.C.y>93&&this.C.y<593)) vertex(this.C.x, this.C.y);
  }
}

// management triangle
class TriangleSystem {
  constructor() {
    this.triangles = [];
  }

  addTriangles(neighbours) {
    let size = neighbours.length;
    if (size > 2) {
      for (let i = 1; i < size - 1; i++) {
        for (let j = i + 1; j < size; j++) {
          if (this.triangles.length < MAX_TRIANGLES) {
            this.triangles.push(
              new Triangle(
                neighbours[0].pos,
                neighbours[i].pos,
                neighbours[j].pos
              )
            );
          }
        }
      }
    }
  }


// The following two parts are showing both hands at the same time and are copied
  display() {
    noStroke();
    stroke(max(colour.R, 0), max(colour.G, 0), max(colour.B, 0), 13);
    fill(amplify(processColor[0]), amplify(processColor[1]), amplify(processColor[2]), 30);
    beginShape(TRIANGLES);
    for (let i = 0; i < this.triangles.length; i++) {

   
       if(i%4==0){
        let t = this.triangles[i];
        t.display();

      }
     
    }
    endShape();
  }
  display2() {
    noStroke();
    stroke(max(colour.R, 0), max(colour.G, 0), max(colour.B, 0), 13);
    fill(250, 5, 153, 30);
    beginShape(TRIANGLES);
    for (let i = 0; i < this.triangles.length; i++) {
      let t = this.triangles[i];
      t.display();
    }
    endShape();
  }

  clear() {
    this.triangles = [];
  }
}

class Wanderer {
  constructor() {
    this.loc = createVector(random(width), random(height));
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.angle = 0;
  }

  update() {
    this.angle += random(0, TWO_PI);
    let magnitude = random(0, 1.5);
    this.acc.x += cos(this.angle) * magnitude;
    this.acc.y += sin(this.angle) * magnitude;
    this.acc.limit(3);
    this.vel.add(this.acc);
    this.vel.limit(MAX_WANDERER_SPEED);
    this.loc.add(this.vel);
    if (this.loc.x > width) this.loc.x -= width;
    if (this.loc.x < 0) this.loc.x += width;
    if (this.loc.y > height) this.loc.y -= height;
    if (this.loc.y < 0) this.loc.y += height;
  }

  display() {
    fill(0);
    ellipse(this.loc.x, this.loc.y, 10, 10);
  }
}

// Take points on the skeletal line of the hand and randomly take points on the back vector to derive the particle
class GetPoints {
  constructor(pr) {
    this.type = floor(random(0, 11));
    this.bones = floor(random(0, 4));
    this.pts = [];
    this.pointA = createVector(0, 0);
    this.pointB = createVector(0, 0);
    this.rate = random(1.01);
    this.pts.push(pr.annotations.palmBase[0]);
    if (this.type == 0) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.thumb[i]);
      }
    } else if (this.type == 1) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.indexFinger[i]);
      }
    } else if (this.type == 2) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.middleFinger[i]);
      }
    } else if (this.type == 3) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.ringFinger[i]);
      }
    } else if (this.type == 4) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.pinky[i]);
      }
    } else if (this.type == 5) {
      for (let i = 1; i <= 2; i++) {
        this.pts.push(pr.landmarks[i]);
      }
      this.bones = floor(random(0, 2));
    } else if (this.type == 6) {
      this.pts.push(pr.landmarks[5]);
      this.bones = floor(random(0, 0));
    } else if (this.type == 7) {
      this.pts.push(pr.landmarks[9]);
      this.bones = floor(random(0, 0));
    } else if (this.type == 8) {
      this.pts.push(pr.landmarks[13]);
      this.bones = floor(random(0, 0));
    } else if (this.type == 9) {
      this.pts.push(pr.landmarks[17]);
      this.bones = floor(random(0, 0));
    } else if (this.type == 10) {
      for (let i = 1; i <= 2; i++) {
        this.pts.push(pr.landmarks[i]);
      }
      this.pts.push(pr.landmarks[5]);
      this.bones = floor(random(0, 3));
    }

    this.pointA = createVector(
      transX(this.pts[this.bones][0]),
      transY(this.pts[this.bones][1])
    );
    this.pointB = createVector(
      transX(this.pts[this.bones + 1][0]),
      transY(this.pts[this.bones + 1][1])
    );
    this.offsetDistance = random(-25, 25);
    this.randomPoint = randomPointOnLine(this.rate, this.pointA, this.pointB);
    this.offsetPoint = offsetPointByWidth(
      this.randomPoint,
      this.pointA,
      this.pointB,
      this.offsetDistance
    );
  }
  update(pr) {
    this.pts = [];
    this.pts.push(pr.annotations.palmBase[0]);
    if (this.type == 0) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.thumb[i]);
      }
    } else if (this.type == 1) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.indexFinger[i]);
      }
    } else if (this.type == 2) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.middleFinger[i]);
      }
    } else if (this.type == 3) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.ringFinger[i]);
      }
    } else if (this.type == 4) {
      for (let i = 3; i >= 0; i--) {
        this.pts.push(pr.annotations.pinky[i]);
      }
    } else if (this.type == 5) {
      for (let i = 1; i <= 2; i++) {
        this.pts.push(pr.landmarks[i]);
      }
      this.bones = floor(random(0, 2));
    } else if (this.type == 6) {
      this.pts.push(pr.landmarks[5]);
      this.bones = floor(random(0, 0));
    } else if (this.type == 7) {
      this.pts.push(pr.landmarks[9]);
      this.bones = floor(random(0, 0));
    } else if (this.type == 8) {
      this.pts.push(pr.landmarks[13]);
      this.bones = floor(random(0, 0));
    } else if (this.type == 9) {
      this.pts.push(pr.landmarks[17]);
      this.bones = floor(random(0, 0));
    } else if (this.type == 10) {
      for (let i = 1; i <= 2; i++) {
        this.pts.push(pr.landmarks[i]);
      }
      this.pts.push(pr.landmarks[5]);
      this.bones = floor(random(0, 3));
    }

    this.pointA = createVector(
      transX(this.pts[this.bones][0]),
      transY(this.pts[this.bones][1])
    );
    this.pointB = createVector(
      transX(this.pts[this.bones + 1][0]),
      transY(this.pts[this.bones + 1][1])
    );
    this.randomPoint = randomPointOnLine(this.rate, this.pointA, this.pointB);
    this.offsetPoint = offsetPointByWidth(
      this.randomPoint,
      this.pointA,
      this.pointB,
      this.offsetDistance
    );
    return this.offsetPoint;
  }
}

function randomPointOnLine(rate, pointA, pointB) {
  let randomPoint = p5.Vector.lerp(pointA, pointB, rate);
  return randomPoint;
}

function offsetPointByWidth(point, pointA, pointB, offsetDistance) {
  let lineDirection = p5.Vector.sub(pointB, pointA);
  lineDirection.normalize();
  let normalDirection = createVector(-lineDirection.y, lineDirection.x);
  let offsetVector = p5.Vector.mult(normalDirection, offsetDistance);
  return p5.Vector.add(point, offsetVector);
}
let wrappedText=[];
let textRoll = `
“1.Please choose your interest group”
“2. Please interact with your social network handshake!”
“3. Congratulations on reaching 5 levels of trust and 5 levels of your interest group!”
“4. Congratulations on reaching 10 levels of trust and 10 levels of your interest group!”
“5. Congratulations on reaching 15 levels of trust and 15 levels of your interest group!”
“6. Congratulations on reaching 20 levels of trust and 20 levels of your interest group!”

`;